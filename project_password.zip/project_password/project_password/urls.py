from django.contrib import admin
from django.urls import include, path

urlpatterns = [
    path('admin/', admin.site.urls),
    # path('password_generator/', include('password_generator.urls')),
    path('', include('password_generator.urls')),
]