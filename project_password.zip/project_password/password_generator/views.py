from optparse import make_option
from pdb import post_mortem
from django.http import HttpResponse, response
import random
from django.shortcuts import render
# import render
from django.template import context, loader


def index(request):
    return render(request,'index.html')

def generate(request):
    #the context is to render value and set value pair for fronend 
    context={}
    #here we are getting value from post method Request 
    user_password=request.POST.get('get_password')
    #puttint the value into u_passs Variable 
    u_pass=user_password
    #here is the symbols to make password more strong
    Numbers_Symbols = [' ','@', '#', '$', '%', '=', ':', '?', '.', '/', '|', '~', '>',
    		        '*', '(', ')', '<','1','2','3','4','5','6','7','8','9','0']
    #in this line of code we are using join function to randmize the user input 
    u_pass=u_pass+random.choice(Numbers_Symbols)
    get_symbols="".join(random.sample(Numbers_Symbols,int(len(u_pass)/2)))
    get_user_pass="".join(random.sample(u_pass,len(u_pass)))
    generated_password=get_symbols+get_user_pass
    
    context['a']=generated_password
    return render(request,'index.html',context)