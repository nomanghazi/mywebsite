from statistics import mode
from django.db import models

# Create your models here.
class User_Password_Generator(models.Model):
    user_input=models.CharField(max_length=200)
